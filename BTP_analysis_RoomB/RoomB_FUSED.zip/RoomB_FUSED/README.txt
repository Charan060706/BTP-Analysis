RoomB_FUSED - Multi-receiver CSI window-summary fusion

Structure:
RoomB_FUSED/C1/Rep01/Fused_window_summary.csv
...
RoomB_FUSED/C8/Rep08/Fused_window_summary.csv

Fusion method:
- Pair matching by scenario and repetition.
- Time-window alignment using the 'second' column.
- Outer join, retaining all second indices present in either receiver.
- Receiver-specific columns are prefixed RX1_ and RX2_.
- RX1_record_present and RX2_record_present indicate whether each receiver supplied a row for that second.
- Missing values are left missing; they are not replaced with zero or interpolated.
- No averaging, feature reduction, or filtering is applied.

Input files:
RoomB_Rx1/.../RX1/window_summary.csv
RoomB_Rx2/.../RX2/window_summary.csv

Note:
These are window-summary files. The fusion preserves the information present in those summaries;
it does not reconstruct raw packet-level CSI or I/Q samples.
See validation_summary.csv for per-repetition row counts and alignment checks.
